-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 31 mai 2019 à 13:50
-- Version du serveur :  5.7.21
-- Version de PHP :  5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `proxybanque`
--
CREATE DATABASE IF NOT EXISTS `proxybanque` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `proxybanque`;

-- --------------------------------------------------------

--
-- Structure de la table `agence`
--

DROP TABLE IF EXISTS `agence`;
CREATE TABLE IF NOT EXISTS `agence` (
  `id` varchar(5) NOT NULL,
  `dateCreation` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `carte`
--

DROP TABLE IF EXISTS `carte`;
CREATE TABLE IF NOT EXISTS `carte` (
  `numCarte` varchar(50) NOT NULL,
  `codeSecret` int(4) NOT NULL,
  `dateExpiration` date NOT NULL,
  `activation` tinyint(1) NOT NULL,
  PRIMARY KEY (`numCarte`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `carteelectron`
--

DROP TABLE IF EXISTS `carteelectron`;
CREATE TABLE IF NOT EXISTS `carteelectron` (
  `idCarte` varchar(50) NOT NULL,
  `typologie` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `cartevisapremier`
--

DROP TABLE IF EXISTS `cartevisapremier`;
CREATE TABLE IF NOT EXISTS `cartevisapremier` (
  `idCarte` varchar(50) NOT NULL,
  `typologie` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

DROP TABLE IF EXISTS `client`;
CREATE TABLE IF NOT EXISTS `client` (
  `idPersonne` varchar(50) NOT NULL,
  `idConseiller` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`idPersonne`, `idConseiller`) VALUES
('1', '1'),
('2', '2');

-- --------------------------------------------------------

--
-- Structure de la table `compte`
--

DROP TABLE IF EXISTS `compte`;
CREATE TABLE IF NOT EXISTS `compte` (
  `numCompte` varchar(50) NOT NULL,
  `solde` float NOT NULL,
  `dateOuverture` date NOT NULL,
  `type` tinyint(1) NOT NULL,
  `idClient` varchar(50) NOT NULL,
  PRIMARY KEY (`numCompte`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `compte`
--

INSERT INTO `compte` (`numCompte`, `solde`, `dateOuverture`, `type`, `idClient`) VALUES
('aa', 2000, '2019-05-16', 0, '1'),
('aaa', 1000, '2019-05-04', 1, '1');

-- --------------------------------------------------------

--
-- Structure de la table `comptecourant`
--

DROP TABLE IF EXISTS `comptecourant`;
CREATE TABLE IF NOT EXISTS `comptecourant` (
  `typologie` varchar(50) NOT NULL,
  `decouvert` float NOT NULL,
  `idCompte` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `compteepargne`
--

DROP TABLE IF EXISTS `compteepargne`;
CREATE TABLE IF NOT EXISTS `compteepargne` (
  `typologie` varchar(50) NOT NULL,
  `tauxRemuneration` int(3) NOT NULL,
  `idCompte` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `gerant`
--

DROP TABLE IF EXISTS `gerant`;
CREATE TABLE IF NOT EXISTS `gerant` (
  `idPerso` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `personne`
--

DROP TABLE IF EXISTS `personne`;
CREATE TABLE IF NOT EXISTS `personne` (
  `id` varchar(50) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `prenom` varchar(50) NOT NULL,
  `adresse` varchar(250) NOT NULL,
  `codePostal` int(5) NOT NULL,
  `ville` varchar(50) NOT NULL,
  `telephone` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `personne`
--

INSERT INTO `personne` (`id`, `nom`, `prenom`, `adresse`, `codePostal`, `ville`, `telephone`) VALUES
('1', 'jean', 'pierre', 'abcvhvfhyvufgbul', 78140, 'lepecq', 10002200),
('2', 'jacky', 'pp', 'vbn,nbvcdsdfghjk', 78140, 'jhgfd', 10002200),
('3', 'le', 'conseiller', 'uhuh', 78140, 'jhh_ou', 10002200);

-- --------------------------------------------------------

--
-- Structure de la table `personnelbanque`
--

DROP TABLE IF EXISTS `personnelbanque`;
CREATE TABLE IF NOT EXISTS `personnelbanque` (
  `gerant` tinyint(1) NOT NULL,
  `idPersonne` varchar(50) NOT NULL,
  `idAgence` varchar(5) NOT NULL,
  `login` varchar(50) NOT NULL,
  `pwd` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `personnelbanque`
--

INSERT INTO `personnelbanque` (`gerant`, `idPersonne`, `idAgence`, `login`, `pwd`) VALUES
(0, '1', '1', 'test', 'test');

-- --------------------------------------------------------

--
-- Structure de la table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
CREATE TABLE IF NOT EXISTS `transaction` (
  `id` varchar(50) NOT NULL,
  `numCompte` varchar(50) NOT NULL,
  `montant` float NOT NULL,
  `dateTransaction` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
