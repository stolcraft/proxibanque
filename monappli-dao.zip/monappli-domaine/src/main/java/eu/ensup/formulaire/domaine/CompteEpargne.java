package eu.ensup.formulaire.domaine;

public class CompteEpargne {

}
