package eu.ensup.formulaire.domaine;

public class Client extends Personne {

}
