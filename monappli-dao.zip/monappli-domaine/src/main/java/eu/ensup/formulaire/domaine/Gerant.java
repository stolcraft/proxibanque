package eu.ensup.formulaire.domaine;

public class Gerant extends Personne {
	
}
