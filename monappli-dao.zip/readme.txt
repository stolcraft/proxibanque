---------------------------------------
Pour faire fonctionner l'application :
----------------------------------------

-Mettre le WAR sous un serveur TOMCAT

-Importer la BDD proxybanque.sql sous mysql (avec id:root et mdp: )

-Lancer l'application, identifiez-vous avec id: test mdp: test