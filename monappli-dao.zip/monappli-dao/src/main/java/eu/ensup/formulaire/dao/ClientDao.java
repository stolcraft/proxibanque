package eu.ensup.formulaire.dao;

public class ClientDao extends AccesBd {

	
}
